var player,
		 time_update_interval = 0;
var player2,

    time_update_interval2 = 0;

function onYouTubeIframeAPIReady() {
    player = new YT.Player('player1', {
        width: "100%",
        height: "100%",
        videoId: 'Xa0Q0J5tOP0',
        playerVars: {
            color: 'white',
            
        },
        events: {
            onReady: initialize1
        }
    });
	
	player2 = new YT.Player('player2', {
        width: "100%",
        height: "100%",
        videoId: 'taJ60kskkns',
        playerVars: {
            color: 'white',
            
        },
        events: {
            onReady: initialize2
        }
    });
	
	
}

function initialize1(){

    // Update the controls on load
    updateTimerDisplay();
    updateProgressBar();

    // Clear any old interval.
    clearInterval(time_update_interval);

    // Start interval to update elapsed time display and
    // the elapsed part of the progress bar every second.
    time_update_interval = setInterval(function () {
        updateTimerDisplay();
        updateProgressBar();
    }, 1000);


    $('#volume-input').val(Math.round(player.getVolume()));
}

function initialize2(){

    // Update the controls on load
    updateTimerDisplay2();
    updateProgressBar2();

    // Clear any old interval.
    clearInterval(time_update_interval2);

    // Start interval to update elapsed time display and
    // the elapsed part of the progress bar every second.
    time_update_interval = setInterval(function () {
        updateTimerDisplay2();
        updateProgressBar2();
    }, 1000);


    $('#volume-input2').val(Math.round(player2.getVolume()));
}




// This function is called by initialize()
function updateTimerDisplay(){
    // Update current time text display.
    $('#current-time').text(formatTime( player.getCurrentTime() ));
    $('#duration').text(formatTime( player.getDuration() ));
}
// This function is called by initialize()
function updateTimerDisplay2(){
    // Update current time text display.
    $('#current-time').text(formatTime( player2.getCurrentTime() ));
    $('#duration').text(formatTime( player2.getDuration() ));
}

// This function is called by initialize()
function updateProgressBar(){
    // Update the value of our progress bar accordingly.
    $('#progress-bar').val((player.getCurrentTime() / player.getDuration()) * 100);
}
// This function is called by initialize()
function updateProgressBar2(){
    // Update the value of our progress bar accordingly.
    $('#progress-bar').val((player2.getCurrentTime() / player2.getDuration()) * 100);
}


// Progress bar

$('#progress-bar').on('mouseup touchend', function (e) {

    // Calculate the new time for the video.
    // new time in seconds = total duration in seconds * ( value of range input / 100 )
    var newTime = player.getDuration() * (e.target.value / 100);

    // Skip video to new time.
    player.seekTo(newTime);

});
// Progress bar

$('#progress-bar2').on('mouseup touchend', function (e) {

    // Calculate the new time for the video.
    // new time in seconds = total duration in seconds * ( value of range input / 100 )
    var newTime2 = player2.getDuration() * (e.target.value / 100);

    // Skip video to new time.
    player2.seekTo(newTime2);

});

// Playback

$('#play').on('click', function () {
    player.playVideo();
});
// Playback

$('#play2').on('click', function () {
    player2.playVideo();
});

$('#pause').on('click', function () {
    player.pauseVideo();
});
$('#pause2').on('click', function () {
    player2.pauseVideo();
});


// Sound volume


$('#mute-toggle').on('click', function() {
    var mute_toggle = $(this);

    if(player.isMuted()){
        player.unMute();
        mute_toggle.text('volume_up');
    }
    else{
        player.mute();
        mute_toggle.text('volume_off');
    }
});

$('#volume-input').on('change', function () {
    player.setVolume($(this).val());
});

// Sound volume


$('#mute-toggle2').on('click', function() {
    var mute_toggle2 = $(this);

    if(player2.isMuted()){
        player2.unMute();
        mute_toggle.text('volume_up');
    }
    else{
        player2.mute();
        mute_toggle.text('volume_off');
    }
});

$('#volume-input2').on('change', function () {
    player2.setVolume($(this).val());
});

// Other options


$('#speed').on('change', function () {
    player.setPlaybackRate($(this).val());
});

$('#quality').on('change', function () {
    player.setPlaybackQuality($(this).val());
});
// Other options


$('#speed2').on('change', function () {
    player2.setPlaybackRate($(this).val());
});

$('#quality2').on('change', function () {
    player2.setPlaybackQuality($(this).val());
});


// Playlist

$('#next').on('click', function () {
    player.nextVideo()
});

$('#prev').on('click', function () {
    player.previousVideo()
});
// Playlist

$('#next2').on('click', function () {
    player2.nextVideo()
});

$('#prev2').on('click', function () {
    player2.previousVideo()
});


// Load video

$('.thumbnail').on('click', function () {

    var url = $(this).attr('data-video-id');

    player.cueVideoById(url);

});

// Load video

$('.thumbnail2').on('click', function () {

    var url2 = $(this).attr('data-video-id');

    player2.cueVideoById(url);

});

// Helper Functions

function formatTime(time){
    time = Math.round(time);

    var minutes = Math.floor(time / 60),
        seconds = time - minutes * 60;

    seconds = seconds < 10 ? '0' + seconds : seconds;

    return minutes + ":" + seconds;
}

// Helper Functions

function formatTime2(time2){
    time2 = Math.round(time2);

    var minutes2 = Math.floor(time / 60),
        seconds2 = time - minutes * 60;

    seconds2 = seconds2 < 10 ? '0' + seconds2 : seconds2;

    return minutes2 + ":" + seconds2;
}
